#aprile 2021
rm(list=objects())
library("tidyverse")
library("guido")
library("janitor")
library("seplyr")
library("fuzzyjoin")
library("DataEditR")

creaCalendario(annoI=2018,annoF=2020)->calendario

#dati del Centro FUnzionale Abruzzo: i dati di precipitazione sono caratterizzati dal suffisso P.csv
list.files(patter="^.+Tmin\\.csv$")->ffile

purrr::map(ffile,.f=~(read_delim(.x,delim=";",
                                 col_names=TRUE,
                                 locale=locale(decimal_mark = ","),
                                 na = c("NA","-"),
                                 col_types = cols(Data=col_date(format="%d/%m/%Y"),Ora=col_character(),.default = col_double()))))->listaDF

#coprono tutti lo stesso periodo? e hanno tutti lo stesso numero di dati?
purrr::map(listaDF,.f=~skimr::skim(.[,"Data"]))
purrr::map(listaDF,.f=~nrow(.))

#ok posso fare il join
purrr::reduce(listaDF,.f=full_join,by="Data") %>%
  dplyr::select(-matches("^Ora.*"),-matches("X[[:digit:]]+")) %>%
  separate(Data,into=c("yy","mm","dd"),sep="-") %>%
  mutate(yy=as.integer(yy),mm=as.integer(mm),dd=as.integer(dd))->dati

stopifnot(nrow(dati)==nrow(calendario))

get_dupes(dati,yy,mm,dd)
#questo join in realta' e' inutile
left_join(calendario,dati)->dati

#i nomi delle colonne riportano il nome della stazione un suffisso che va eliminato
normalizza<-function(x){tolower(str_trim(x,side="both"))}
names(dati)<-str_remove(names(dati)," - (t|T).* - Minime.+")
names(dati)<-normalizza(names(dati))

read_delim("reg.abruzzo.info.csv",delim=";",col_names = TRUE) %>%
  mutate(SiteName=normalizza(SiteName))->ana


dati %>%
  gather(key="SiteName",value="value",-yy,-mm,-dd)->gdati

#la colonna verifica contiene la distanza tra una stringa e l'altra, vanno verificate distanza !=0
fuzzyjoin::stringdist_full_join(gdati,ana[,c("SiteName","SiteID")],by=c(SiteName="SiteName"),max_dist=4,distance_col="verifica")->finale

finale[!duplicated(finale[,c("SiteName.x","SiteName.y","SiteID","verifica"),]),]->ulterioreVerifica

#DataEditR::data_edit(ulterioreVerifica %>% arrange(verifica),save_as="associazioni.csv",write_fun = write_delim,write_args = list(col_names=TRUE,delim=";"),viewer=FALSE)

#dopo aver riferificato ilfile associazioni.csv lo ricarico: a questo punto ho risolto manualmente le eventuali non associazioni
read_delim("associazioni.csv",delim=";",col_names = TRUE)->associazioni


left_join(gdati,associazioni[,c("SiteName.x","SiteID")],by=c("SiteName"="SiteName.x"))->finale
which(is.na(finale$SiteID))->righe
unique(finale[righe,]$SiteName)->daEliminare #queste sono stazioni che in nessunmodo riusciamoa identificare: pescara (invece) dovrebbe essere la stazione dell'aeronautica (pescara meteo)

finale %>%
  filter(!is.na(SiteID)) %>%
  dplyr::select(-SiteName) %>%
  spread(key=SiteID,value=value)->finale2

skimr::skim(finale2)


write_delim(finale2,"Tmin_abruzzo_2018_2020.csv",delim=";",col_names = TRUE)