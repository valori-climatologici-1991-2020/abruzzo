#Nel 2021 sono stati richiesti i dati di Abruzzo per 2018-2020. Successivamente sono stati richiesti all'Abruzzo i dati 1991-2017
#con la speranza di avere dati molto piu' completi di quelli disponibili, soprattutto per calcolare i valori climatologici 1991-2020.

#Questo script legge i dati inviati dall'Abruzzo. Il delimitatore "\" e' stato trasformato mediante Calc in ";" e il file e' stato
#salvato con un encoding europeo diverso da UTF-8 per evitare gli strani caratteri nel file di testo dell'Abruzzo.
rm(list=objects())
library("tidyverse")

system("rm -rf temp.csv")

purrr::partial(.f=str_trim,side="both")->togli_spazi

read_lines("guido_Pluvio [Dati giornalieri][1-10000][2009-2017].csv",n_max = 160000)->righe

codiceStazione<-""
nomeStazione<-""
anno<-""

purrr::walk(righe,.f=function(rr){
  
  if(grepl("^ *[[:digit:]]+ - .+;+",rr)){
    str_remove(rr,";+")->rr
    togli_spazi(str_extract(rr,"^ *[[:digit:]]+"))->>codiceStazione
    togli_spazi(str_remove(str_extract(rr,"- .+"),"-"))->>nomeStazione
  }

  if(grepl("^ *; *(1|2)[0-9]{3}",rr)) str_extract(rr,"[0-9]{4}")->>anno
  
  if(grepl("^ *;[0-9]{1,2};",rr)){
    
    str_c(nomeStazione,rr,sep="")->rr
    str_c(anno,codiceStazione,rr,sep=";")->rr
    str_replace_all(rr,",",".")->rr

    write_lines(rr,file="temp.csv",append=TRUE)
  
  }  
  NULL
  
})

read_delim("temp.csv",delim=";",col_names = FALSE,col_types = cols(.default = col_character()))->dati
names(dati)<-c("yy","SiteCode","StationName","dd",str_c("X",1:12))


dati %>%
  gather(key="mm",value="value",-yy,-SiteCode,-StationName,-dd) %>%
  mutate(mm=str_remove(mm,"X")) %>%
  mutate(value=str_replace_all(value,"\\?","0.0")) %>%
  mutate(value=as.numeric(value)) %>%
  mutate(SiteCode=as.character(SiteCode))->dati3

read_delim("../reg.abruzzo.info.csv",delim=";",col_names = TRUE) %>%
  mutate(SiteCode=as.character(SiteCode))->ana

left_join(dati3,ana) %>%
  dplyr::select(yy,mm,dd,SiteID,value) %>%
  filter(!is.na(SiteID))->dati4



dati4 %>%
  spread(key=SiteID,value=value)->Prec

min(Prec$yy)->annoI
max(Prec$yy)->annoF

write_delim(Prec,glue::glue("Prec_{annoI}_{annoF}.csv"),delim=";",col_names = TRUE)

