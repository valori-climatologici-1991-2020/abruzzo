rm(list=objects())
library("tidyverse")

system("rm -rf temp.csv")

purrr::partial(.f=str_trim,side="both")->togli_spazi

read_lines("guido_Termo[Dati giornalieri][10 10000][2009 2020].csv",n_max = 160000)->righe

codiceStazione<-""
nomeStazione<-""
anno<-""

purrr::walk(righe,.f=function(rr){
  
  if(grepl("^ *[[:digit:]]+ - .+;+",rr)){
    str_remove(rr,";+")->rr
    togli_spazi(str_extract(rr,"^ *[[:digit:]]+"))->>codiceStazione
    togli_spazi(str_remove(str_extract(rr,"- .+"),"-"))->>nomeStazione
  }

  if(grepl("^ *; *(1|2)[0-9]{3}",rr)) str_extract(rr,"[0-9]{4}")->>anno
  
  if(grepl("^ *;[0-9]{1,2};",rr)){
    
    str_c(nomeStazione,rr,sep="")->rr
    str_c(anno,codiceStazione,rr,sep=";")->rr
    str_replace_all(rr,",",".")->rr

    write_lines(rr,file="temp.csv",append=TRUE)
  
  }  
  NULL
  
})

read_delim("temp.csv",delim=";",col_names = FALSE,col_types = cols(.default = col_character()))->dati
names(dati)<-c("yy","SiteCode","StationName","dd",str_c("X",1:6),"dd2")
dati$dd2<-NULL
nrow(dati)/62->ndati
dati$stagione<-rep(rep(c("primi6","ultimi6"),each=31),times=ndati)

dati %>%
  filter(grepl("primi",stagione)) %>%
  dplyr::select(-stagione)->primi_6_mesi

dati %>%
  filter(grepl("ultimi",stagione)) %>%
  rename(X7=X1,X8=X2,X9=X3,X10=X4,X11=X5,X12=X6) %>%
  dplyr::select(-stagione)->ultimi_6_mesi

full_join(primi_6_mesi,ultimi_6_mesi)->dati2

dati2 %>%
  gather(key="mm",value="value",-yy,-SiteCode,-StationName,-dd) %>%
  mutate(mm=str_remove(mm,"X")) %>%
  mutate(value=str_remove(value,"^[[:space:]]+")) %>%
  mutate(value=str_replace_all(value,"<","")) %>%
  mutate(value=str_replace(value,"[[:space:]]+",";")) %>%
  separate(value,into=c("Tmax","Tmin"),sep=";") %>%
  mutate(Tmax=as.numeric(Tmax),Tmin=as.double(Tmin)) %>%
  mutate(SiteCode=as.character(SiteCode))->dati3

read_delim("../reg.abruzzo.info.csv",delim=";",col_names = TRUE) %>%
  mutate(SiteCode=as.character(SiteCode))->ana

left_join(dati3,ana) %>%
  dplyr::select(yy,mm,dd,SiteID,Tmax,Tmin) %>%
  filter(!is.na(SiteID))->dati4



dati4 %>%
  dplyr::select(-Tmin) %>%
  spread(key=SiteID,value=Tmax)->Tmax

min(Tmax$yy)->annoI
max(Tmax$yy)->annoF

write_delim(Tmax,glue::glue("Tmax_{annoI}_{annoF}.csv"),delim=";",col_names = TRUE)

dati4 %>%
  dplyr::select(-Tmax) %>%
  spread(key=SiteID,value=Tmin)->Tmin

write_delim(Tmin,glue::glue("Tmin_{annoI}_{annoF}.csv"),delim=";",col_names = TRUE)

